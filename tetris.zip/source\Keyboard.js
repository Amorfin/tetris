﻿import Display      from "./Display.js";
import HighScores   from "./HighScores.js";

// Utils
import KeyCode      from "../utils/KeyCode.js";



/**
 * Neon Blocks Keyboard
 */
export default class Keyboard {

    /**
     * Neon Blocks Keyboard constructor
     * @param {Display}    display
     * @param {HighScores} scores
     * @param {Object}     shortcuts
     */
    constructor(display, scores, shortcuts) {
        this.shortcuts  = shortcuts;
        this.keyPressed = null;
        this.downAt     = 0;
        this.lastHold   = 0;

        this.display    = display;
        this.scores     = scores;

        document.addEventListener("keydown", (e) => this.onKeyDown(e));
        document.addEventListener("keyup",   (e) => this.onKeyUp());
    }



    /**
     * Called when holding a key
     */
    holdingKey() {
        if (this.keyPressed !== null) {
            const now    = performance.now();
            const isDown = KeyCode.isDown(this.keyPressed);
            const delay  = isDown ? 60 : 200;
            const rate   = isDown ? 35 : 70;

            if (now - this.downAt >= delay && now - this.lastHold >= rate) {
                this.onKeyHold();
                this.lastHold = now;
            }
        }
    }

    /**
     * Resets the counter
     */
    reset() {
        this.keyPressed = null;
        this.downAt     = 0;
        this.lastHold   = 0;
    }



    /**
     * Key Press Event
     * @param {Number}         key
     * @param {KeyboardEvent=} event
     * @returns {Void}
     */
    pressKey(key, event) {
        const keyCode  = KeyCode.keyToCode(key);
        const number   = KeyCode.keyToNumber(key, true);
        let   shortcut = "";

        if (this.scores.isFocused) {
            if (KeyCode.isEnter(key)) {
                this.shortcuts.gameOver.O();
            }
        } else {
            if (!this.display.isPlaying) {
                event.preventDefault();
            }

            if ([ "Enter", "Return", "O" ].includes(keyCode)) {
                shortcut = "O";
            } else if (KeyCode.isErase(key)) {
                shortcut = "B";
            } else if (KeyCode.isPauseContinue(key)) {
                shortcut = "P";
            } else if (KeyCode.isUp(key)) {
                shortcut = "W";
            } else if (KeyCode.isLeft(key)) {
                shortcut = "A";
            } else if (KeyCode.isDown(key)) {
                shortcut = "S";
            } else if (KeyCode.isRight(key)) {
                shortcut = "D";
            } else {
                shortcut = keyCode;
            }

            if (number !== null) {
                this.shortcuts.number(number);
            } else if (this.shortcuts[this.display.current][shortcut]) {
                this.shortcuts[this.display.current][shortcut]();
            }
        }
    }

    /**
     * Key handler for the on key down event
     * @param {KeyboardEvent} event
     * @returns {Void}
     */
    onKeyDown(event) {
        if (this.scores.isFocused) {
            if (KeyCode.isEnter(event.keyCode)) {
                event.preventDefault();
                this.pressKey(event.keyCode, event);
            }
            return;
        }

        const keyCode = KeyCode.keyToCode(event.keyCode);
        const handledKeys = [
            "Left", "Right", "Up", "Down",
            "A", "D", "W", "S", "Z", "X", "C",
            "P", "M", "N", "O", "I", "H", "B", "R",
            "Enter", "Return"
        ];
        if (handledKeys.includes(keyCode)) {
            event.preventDefault();
        }

        if (this.display.isPlaying && KeyCode.isFastKey(event.keyCode)) {
            if (this.keyPressed === null) {
                this.keyPressed = event.keyCode;
                const now = performance.now();
                this.downAt   = now;
                this.lastHold = now;
            } else {
                return;
            }
        }
        this.pressKey(event.keyCode, event);
    }

    /**
     * Key handler for the on key up event
     * @returns {Void}
     */
    onKeyUp() {
        this.keyPressed = null;
        this.downAt     = 0;
        this.lastHold   = 0;
    }

    /**
     * When a key is pressed, this is called on each frame for fast key movements
     * @returns {Void}
     */
    onKeyHold() {
        if (this.keyPressed !== null && this.display.isPlaying) {
            this.pressKey(this.keyPressed);
        }
    }
}

